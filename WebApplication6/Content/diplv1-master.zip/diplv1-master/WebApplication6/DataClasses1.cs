namespace WebApplication6
{

    partial class DataClasses1DataContext
    {
    }
}
