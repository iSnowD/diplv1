﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication6.Model
{
    public class MatrixView
    {

        public string m11 { get; set; }
        public string m12 { get; set; }
        public string m21 { get; set; }
        public string m22 { get; set; }
        public string m31 { get; set; }
        public string m32 { get; set; }

        public string m41 { get; set; }
        public string m42 { get; set; }

        public string m51 { get; set; }
        public string m52 { get; set; }

        public string result { get; set; }





    }
}